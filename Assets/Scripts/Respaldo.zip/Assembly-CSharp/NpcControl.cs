using System.Collections;
using UnityEngine;

public class NpcControl : MonoBehaviour
{
	public Rigidbody2D projectile;

	private Rigidbody2D rb;

	private SpriteRenderer sprite;

	private Player player;

	public HealthBar hb;

	private Animator a;

	public int health;

	public int dir;

	public int healthDeduction;

	public float xSpeed;

	public float yScale;

	public float xScale;

	private bool awake;

	public float myPltY;

	private void Start()
	{
		hb.setMaxHealth(health);
		player = Object.FindObjectOfType<Player>();
		sprite = GetComponent<SpriteRenderer>();
		a = GetComponent<Animator>();
	}

	private void Update()
	{
		awake = playerAccessible();
		if (player.gameObject.transform.position.x <= base.transform.position.x)
		{
			base.transform.localScale = new Vector2(0f - xScale, yScale);
			dir = -1;
		}
		else
		{
			base.transform.localScale = new Vector2(xScale, yScale);
			dir = 1;
		}
		if (health <= 0)
		{
			Object.Destroy(base.gameObject);
		}
		if ((base.tag == "zombie" || base.tag == "wolf") && !player.isHit && awake)
		{
			rb = GetComponent<Rigidbody2D>();
			rb.velocity = new Vector2(xSpeed * (float)dir, rb.velocity.y);
		}
		if (!base.name.StartsWith("plantz"))
		{
			a.SetBool("moving", awake);
		}
		hb.setHealth(health);
	}

	private bool playerAccessible()
	{
		if (player.rb.velocity.x == 0f && player.rb.velocity.y == 0f && Mathf.Abs(player.transform.position.y - base.transform.position.y) > 1f)
		{
			return false;
		}
		return true;
	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "shuriken")
		{
			healthDeduction = 1;
			damageRoutine();
		}
		if (other.name.StartsWith("strike"))
		{
			healthDeduction = 3;
			damageRoutine();
		}
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.collider.tag == "Player" && !player.isDashing && player.canBeHit)
		{
			if (player.transform.position.x > base.transform.position.x)
			{
				player.npcBehind = true;
			}
			else
			{
				player.npcBehind = false;
			}
			player.isHit = true;
		}
	}

	private void projectiler()
	{
		if (awake)
		{
			Object.Instantiate(projectile, new Vector2(base.transform.position.x + 1.5f * (float)dir, base.transform.position.y - 0.1f), base.transform.rotation);
		}
	}

	public void damageRoutine()
	{
		StartCoroutine("damageRoutineActual");
	}

	public IEnumerator damageRoutineActual()
	{
		Object.FindObjectOfType<AudioManager>().Play("npcDamage");
		sprite.color = new Color(1f, 0f, 0f, 1f);
		yield return new WaitForSeconds(0.2f);
		sprite.color = new Color(1f, 1f, 1f, 1f);
		health -= healthDeduction;
	}
}
